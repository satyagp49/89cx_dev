//timer0.h
#include "global.h"

#define TIMER0_COUNT 0xFF00 /* 10000h - ((11,059,200 Hz / (12 * FREQ)) - 17) */

void timer0_init(void (*isr_handler)());