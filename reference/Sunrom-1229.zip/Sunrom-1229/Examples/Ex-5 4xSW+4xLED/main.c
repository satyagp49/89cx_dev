#include <REG51.H>

// Corresponding LED lit up as switch is pressed

sbit SW1  = P2^0;
sbit SW2  = P2^1;
sbit SW3  = P2^2;
sbit SW4  = P2^3;

sbit LED1 = P2^4;
sbit LED2 = P2^5;
sbit LED3 = P2^6;
sbit LED4 = P2^7;

void main()
{
	while(1)
	{
		LED1 = SW1;
		LED2 = SW2;
		LED3 = SW3;
		LED4 = SW4;
	}	
}
