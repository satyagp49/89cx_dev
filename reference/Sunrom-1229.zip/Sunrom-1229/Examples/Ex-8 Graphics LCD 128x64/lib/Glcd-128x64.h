#include "global.h"
/*
***********************************************************************************************
*					JHD12864G/J Graphical LCD Display Driver (KS0107/8 controller)
*
* File name		: ks0108.c
* Programmer 	: John Leung, TechToys. Hong Kong
* Web presence  : www.TechToys.com.hk
* Note			: 
* Language		: Keil C 7.09 2K limited version in uVision2 IDE version 2.40
* Hardware		: AT89S52-gLCD-STK1 demo board
* Date			: Version 1.0 (8th May 2006) - (4th July 2006)
***********************************************************************************************
*										DESCRIPTION
*
* This module provides an interface to JHD12864J Graphical LCD module of size 128x64 dots
* Display controller chip is KS0107/8
* LCD pinout function summarized as below
* --------- LCD		MCU -----------------
* pin 1		Vss 	- 0V
* pin 2 	Vdd 	- 5.0V
* pin 3		Vo  	- LCD Drive Voltage (adjust contrast, trimmer to Vee in our case)
* pin 4		D/I		- LCD_DI (H:Data, L:Command (data or command control))
* pin 5		R/W 	- LCD_RW (H:Read, L:Write (read status or write data/command))
* pin 6		E   	- LCD_EN (H/H->L (IC Select or chip enable, H->L effective))
* pin 7:14	DB0:DB7	- LCD_DATA
* pin 15	CS1		- LCD_CS1 (left, high effective)
* pin 16	CS2		- LCD_CS2 (right, high effective)
* pin 17	RST		- LCD_RST (reset pin, low effective)
* pin 18	Vee		- -10.0V, LCD driving voltage. There is a Vee generator built-in LCD
*					  module, thus there is no need to use external generator IC
* pin 19	EL1 / A - LCD_BL (Depends on the backlight option.
*						If it's a LED backlight, it's an anode.
*					  	If it is EL type, this is EL controller input)
* pin 20	EL2 / K	- GND (Cathode for LED-backlight. EL input (OR NC) for EL-backlight model)
***********************************************************************************************
*/

#ifndef _KS0108_H_
#define _KS0108_H_

#define PIXEL_FONT_EN 		1
#if 	PIXEL_FONT_EN
#define MAX_FONT_WIDTH 		8

typedef struct _font
	{
	unsigned char fontWidth;
	unsigned char fontBody[MAX_FONT_WIDTH];
	}font;
#endif

#define PIXEL_PAT_EN		0
#if		PIXEL_PAT_EN
#define MAX_PAT_SIZE 		48*8
typedef struct _pattern
	{
	unsigned char patWidth;
	unsigned char patHeight;
	unsigned char patBody[MAX_PAT_SIZE];
	}pattern;
#endif

/*
***********************************************************************************************
*										PORT DEFINITION
***********************************************************************************************
*/

//I/O port for data definition
#define LCD_DATA		   	P0

//Control pin setting (Keil C specific for 8051)
sbit	LCD_EN  =			P1^0;
sbit	LCD_RW	=			P1^1;
sbit    LCD_DI	=			P1^2;
sbit 	LCD_CS1 =			P1^3;	
sbit	LCD_CS2	=			P1^4;
sbit	LCD_RST	=			P1^5;
//sbit	LCD_BL	=			P3^7;

/*
***********************************************************************************************
*										GLOBAL CONSTANTS
***********************************************************************************************
*/

#define MAX_ROW_PIXEL		64		//MAX_ROW_PIXEL the physical matrix length (y direction)									
#define MAX_COL_PIXEL		128		//MAX_COL_PIXEL the physical matrix width (x direction)
#define ENABLE				1
#define DISABLE				0
#define BLACK				1
#define WHITE				0


/*
***********************************************************************************************
*									FUNCTION PROTOTYPES
***********************************************************************************************
*/
void GDispInit(void);
void GDispSwitch(bit sw);
void GDispWrByte(unsigned char col, unsigned char page, unsigned char c);
void GDispClr(unsigned char pat);
void GDispSetPixel(unsigned char x, unsigned char y, bit color);
#if PIXEL_PAT_EN
void GDispPixPatAt(unsigned char x, unsigned char y, pattern* pPat, bit color);
#endif
#if PIXEL_FONT_EN
void GDispPixStrAt(unsigned char x, unsigned char y, unsigned char *pStr, \
unsigned char fontSpace, bit color);
#endif

/*
***********************************************************************************************
*									FUNCTION PROTOTYPES
*									 HARDWARE SPECIFIC
***********************************************************************************************
*/
void 			GDispReset(void);
void			GDispChipSel(unsigned char wing); 
void 			GDispWr(bit type, unsigned char dat);
unsigned char 	GDispRd(bit type);
void 			GDispBackLite(bit ctrl);
#endif
