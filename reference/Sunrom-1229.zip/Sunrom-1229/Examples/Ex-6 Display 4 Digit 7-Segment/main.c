#include <stdio.h> // for printf

#include "global.h"
#include "delay.h"			  
#include "timer0.h"			  
#include "seven-segment.h"			  

unsigned int count;	// we will create a count variable and make it go from 0 to 9999

void main()
{
	display_init();
	timer0_init(&display_refresh); // timer0 overflow at 10ms to call display refresh

	count = 1234;
	while(1)
	{
		display_integer(count);		// show integer on display

		count++;					// increment counter every second
		if(count>9999) 
			count = 0; 	//reset back to zero when it reaches 9999

		delay_ms(500);
	}	
}





