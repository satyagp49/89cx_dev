//lcd-16x2.c
#include "lcd-16x2.h"

// initializes the LCD display (gets it ready for use)
void lcd_init(void);

// moves the cursor/position to Home (upper left corner)
//void lcd_home(void);

// clears the LCD display
void lcd_clear(void);

// moves the cursor/position to the line,col requested
void lcd_gotolc(unsigned char line, unsigned char col);

// prints a series of bytes/characters to the display
void lcd_print(char* sdata);


// port you will use for data lines
sfr LCD_DATA  = LCD_PORT;

// port and pins you will use for control lines
sbit    LCD_CTRL_E   = LCD_PORT^0;
sbit    LCD_CTRL_RS  = LCD_PORT^1;
sbit    LCD_BUSY     = LCD_PORT^7;

// LCD display geometry
// change these definitions to adapt settings
#define LCD_LINES            	2   // visible lines
#define LCD_LINE_LENGTH         16   // line length (in characters)
// cursor position to DDRAM mapping
#define LCD_LINE0_DDRAMADDR      0x00
#define LCD_LINE1_DDRAMADDR      0x40
#define LCD_LINE2_DDRAMADDR      0x14
#define LCD_LINE3_DDRAMADDR      0x54

// LCD delay
// This delay affects how quickly accesses are made to the LCD controller.
// If your clock frequency is low, you can reduce the number of NOPs in the
// delay.  If your clock frequency is high, you may need to add NOPs.
// The number of NOPs should be between at least 1 and up to 20.
#define LCD_DELAY   {/*_nop_();_nop_();_nop_();_nop_();_nop_();*/};


// HD44780 LCD controller command set (do not modify these)
// writing:
#define LCD_CLR             0      // DB0: clear display
#define LCD_HOME            1      // DB1: return to home position
#define LCD_ENTRY_MODE      2      // DB2: set entry mode
#define LCD_ENTRY_INC       1      //   DB1: increment
#define LCD_ENTRY_SHIFT     0      //   DB2: shift
#define LCD_ON_CTRL         3      // DB3: turn lcd/cursor on
#define LCD_ON_DISPLAY      2      //   DB2: turn display on
#define LCD_ON_CURSOR       1      //   DB1: turn cursor on
#define LCD_ON_BLINK        0      //   DB0: blinking cursor
#define LCD_MOVE            4      // DB4: move cursor/display
#define LCD_MOVE_DISP       3      //   DB3: move display (0-> move cursor)
#define LCD_MOVE_RIGHT      2      //   DB2: move right (0-> left)
#define LCD_FUNCTION        5      // DB5: function set
#define LCD_FUNCTION_8BIT   4      //   DB4: set 8BIT mode (0->4BIT mode)
#define LCD_FUNCTION_2LINES 3      //   DB3: two lines (0->one line)
#define LCD_FUNCTION_10DOTS 2      //   DB2: 5x10 font (0->5x7 font)
#define LCD_CGRAM           6      // DB6: set CG RAM address
#define LCD_DDRAM           7      // DB7: set DD RAM address
// reading:
//#define LCD_BUSY            7      // DB7: LCD is busy

// Default LCD setup
// this default setup is loaded on LCD initialization
#define LCD_FDEF_1         (0<<LCD_FUNCTION_8BIT)

#define LCD_FDEF_2            (1<<LCD_FUNCTION_2LINES)
#define LCD_FUNCTION_DEFAULT   ((1<<LCD_FUNCTION) | LCD_FDEF_1 | LCD_FDEF_2)
#define LCD_MODE_DEFAULT      ((1<<LCD_ENTRY_MODE) | (1<<LCD_ENTRY_INC))

// custom LCD characters
#define LCDCHAR_PROGRESS05      0   // 0/5 full progress block
#define LCDCHAR_PROGRESS15      1   // 1/5 full progress block
#define LCDCHAR_PROGRESS25      2   // 2/5 full progress block
#define LCDCHAR_PROGRESS35      3   // 3/5 full progress block
#define LCDCHAR_PROGRESS45      4   // 4/5 full progress block
#define LCDCHAR_PROGRESS55      5   // 5/5 full progress block
#define LCDCHAR_REWINDARROW      6   // rewind arrow
#define LCDCHAR_STOPBLOCK      7   // stop block
#define LCDCHAR_PAUSEBARS      8   // pause bars
#define LCDCHAR_FORWARDARROW   9   // fast-forward arrow
#define LCDCHAR_SCROLLUPARROW   10   // scroll up arrow
#define LCDCHAR_SCROLLDNARROW   11   // scroll down arrow
#define LCDCHAR_BLANK         12   // scroll down arrow
#define LCDCHAR_ANIPLAYICON0   13   // animated play icon frame 0
#define LCDCHAR_ANIPLAYICON1   14   // animated play icon frame 1
#define LCDCHAR_ANIPLAYICON2   15   // animated play icon frame 2
#define LCDCHAR_ANIPLAYICON3   16   // animated play icon frame 3

// progress bar defines
#define PROGRESSPIXELS_PER_CHAR   6


// ****** Low-level functions ******
// the following functions are the only ones which deal with the CPU
// memory or port pins directly.  If you decide to use a fundamentally
// different hardware interface to your LCD, only these functions need
// to be changed, after which all the high-level functions will
// work again.

// initializes I/O pins connected to LCD
void lcdInitHW(void);
// waits until LCD is not busy
//void lcdBusyWait(void);
// writes a control command to the LCD
void lcdControlWrite(unsigned char sdata);
// read the control status from the LCD
unsigned char lcdControlRead(void);
// writes a data byte to the LCD screen at the current position
void lcdDataWrite(unsigned char sdata);
// reads the data byte on the LCD screen at the current position
unsigned char lcdDataRead(void);


/*************************************************************/
/********************** LOCAL FUNCTIONS **********************/
/*************************************************************/
void delaymslcd(int x)    // delays x msec (at fosc=11.0592MHz)
{
   int j=0;
   while(x>=0)
   {
      for (j=0; j<100; j++);
      x--;
   }
}
void lcdInitHW(void)
{
   // initialize I/O ports
   // initialize LCD control lines
   LCD_CTRL_RS = 0;
//   LCD_CTRL_RW = 0;
   LCD_CTRL_E = 0;
   // initialize LCD data lines to pull-up
//      LCD_DATA |= 0x0F;   // set pull-ups to on (4bit)
      LCD_DATA |= 0xF0;   // set pull-ups to on (4bit)
}

void lcdBusyWait(void)
{
   // wait until LCD busy bit goes to zero
   // do a read from control register
   LCD_CTRL_RS = 0;            // set RS to "control"
//   LCD_DATA |= 0x0F;   // set pull-ups to on (4bit)
   LCD_DATA |= 0xF0;   // set pull-ups to on (4bit)
  // LCD_CTRL_RW = 1;            // set R/W to "read"
   LCD_CTRL_E = 1;               // set "E" line
   LCD_DELAY;                        // wait
   while(LCD_BUSY == 1)
   {
      LCD_CTRL_E = 0;      // clear "E" line
      LCD_DELAY;                           // wait
      LCD_DELAY;                           // wait
      LCD_CTRL_E = 1;      // set "E" line
      LCD_DELAY;                           // wait
      LCD_DELAY;                           // wait
                  // do an extra clock for 4 bit reads
      LCD_CTRL_E = 0;      // clear "E" line
      LCD_DELAY;                           // wait
      LCD_DELAY;                           // wait
      LCD_CTRL_E = 1;      // set "E" line
      LCD_DELAY;                           // wait
      LCD_DELAY;                           // wait

   }
      LCD_CTRL_E = 0;      // clear "E" line
   //   leave data lines in input mode so they can be most easily used for other purposes
}
 
void lcdControlWrite(unsigned char sdata) 
{
// write the control byte to the display controller

   //lcdBusyWait();                     // wait until LCD not busy
   delaymslcd(1);   // wait
   LCD_CTRL_RS = 0;         // set RS to "control"
//   LCD_CTRL_RW = 0;         // set R/W to "write"
      // 4 bit write
      LCD_CTRL_E = 1;   // set "E" line
//      LCD_DATA = (LCD_DATA&0xF0) | (sdata>>4) ;   // output data, high 4 bits
      LCD_DATA = (LCD_DATA&0x0F) | (sdata&0xF0) ;   // output data, high 4 bits
      LCD_DELAY;                        // wait
      LCD_DELAY;                        // wait
      LCD_CTRL_E = 0;   // clear "E" line
      LCD_DELAY;                        // wait
      LCD_DELAY;                        // wait
      LCD_CTRL_E = 1;   // set "E" line
//      LCD_DATA = (LCD_DATA&0xF0) | (sdata&0x0F) ;   // output data, low 4 bits
      LCD_DATA = (LCD_DATA&0x0F) | (sdata<<4) ;   // output data, low 4 bits
      LCD_DELAY;                        // wait
      LCD_DELAY;                        // wait
      LCD_CTRL_E = 0;   // clear "E" line

   //   leave data lines in input mode so they can be most easily used for other purposes
//      LCD_DATA |= 0x0F;   // set pull-ups to on (4bit)
      LCD_DATA |= 0xF0;   // set pull-ups to on (4bit)
}
/*
unsigned char lcdControlRead(void)
{
// read the control byte from the display controller
   register unsigned char sdata;
   lcdBusyWait();            // wait until LCD not busy
//   LCD_DATA |= 0x0F;   // set pull-ups to on (4bit)
   LCD_DATA |= 0xF0;   // set pull-ups to on (4bit)
   LCD_CTRL_RS = 0;      // set RS to "control"
   LCD_CTRL_RW = 1;      // set R/W to "read"

      // 4 bit read
      LCD_CTRL_E = 1;   // set "E" line
      LCD_DELAY;                  // wait
      LCD_DELAY;                  // wait
//      sdata = (LCD_DATA<<4) & 0xF0;   // input data, high 4 bits
      sdata = (LCD_DATA) & 0xF0;   // input data, high 4 bits
      LCD_CTRL_E = 0;   // clear "E" line
      LCD_DELAY;                  // wait
      LCD_DELAY;                  // wait
      LCD_CTRL_E = 1;   // set "E" line
      LCD_DELAY;                  // wait
      LCD_DELAY;                  // wait
//      sdata |= (LCD_DATA&0x0F);   // input data, low 4 bits
      sdata |= (LCD_DATA>>4)&0x0F;   // input data, low 4 bits
      LCD_CTRL_E = 0;   // clear "E" line

   //   leave data lines in input mode so they can be most easily used for other purposes
   return sdata;
}
*/
void lcdDataWrite(unsigned char sdata) 
{
// write a data byte to the display
//   lcdBusyWait();                     // wait until LCD not busy
   //delaymslcd(5);   // wait
   LCD_CTRL_RS = 1;      // set RS to "data"
//   LCD_CTRL_RW = 0;      // set R/W to "write"
      // 4 bit write
      LCD_CTRL_E = 1;   // set "E" line
//      LCD_DATA = (LCD_DATA & 0xF0) | (sdata>>4) ;   // output data, high 4 bits
      LCD_DATA = (LCD_DATA & 0x0F) | (sdata & 0xF0) ;   // output data, high 4 bits
      LCD_DELAY;                        // wait
      LCD_DELAY;                        // wait
      LCD_CTRL_E = 0;   // clear "E" line
      LCD_DELAY;                        // wait
      LCD_DELAY;                        // wait
      LCD_CTRL_E = 1;   // set "E" line
//      LCD_DATA = (LCD_DATA & 0xF0) | (sdata & 0x0F);   // output data, low 4 bits
      LCD_DATA = (LCD_DATA & 0x0F) | (sdata<<4);   // output data, low 4 bits
      LCD_DELAY;                        // wait
      LCD_DELAY;                        // wait
      LCD_CTRL_E = 0;   // clear "E" line

   //   leave data lines in input mode so they can be most easily used for other purposes
//      LCD_DATA |= 0x0F;
      LCD_DATA |= 0xF0;

}
 /*
unsigned char lcdDataRead(void)
{
// read a data byte from the display
   register unsigned char sdata;
   lcdBusyWait();            // wait until LCD not busy
//   LCD_DATA |= 0x0F;   // set pull-ups to on (4bit)
   LCD_DATA |= 0xF0;   // set pull-ups to on (4bit)
   LCD_CTRL_RS = 1;      // set RS to "data"
   LCD_CTRL_RW = 1;      // set R/W to "read"
      // 4 bit read
      LCD_CTRL_E = 1;               // set "E" line
      LCD_DELAY;                  // wait
      LCD_DELAY;                  // wait
//      sdata = (LCD_DATA<<4) & 0xF0;   // input data, high 4 bits
      sdata = (LCD_DATA) & 0xF0;   // input data, high 4 bits
      LCD_CTRL_E = 0;               // clear "E" line
      LCD_DELAY;                  // wait
      LCD_DELAY;                  // wait
      LCD_CTRL_E = 1;   // set "E" line
      LCD_DELAY;                        // wait
      LCD_DELAY;                        // wait
//      sdata |= (LCD_DATA & 0x0F);         // input data, low 4 bits
      sdata |= (LCD_DATA>>4) & 0x0F;         // input data, low 4 bits
      LCD_CTRL_E = 0 ;   // clear "E" line
   //   leave data lines in input mode so they can be most easily used for other purposes
   return sdata;
}					 


      */
/*************************************************************/
/********************* PUBLIC FUNCTIONS **********************/
/*************************************************************/

void lcd_init()
{
   // initialize hardware
   lcdInitHW();

   // LCD function set
   lcdControlWrite(LCD_FUNCTION_DEFAULT);

   // clear LCD
   lcdControlWrite(1<<LCD_CLR);
   delaymslcd(10);   // wait 60ms
   // set entry mode
   lcdControlWrite(1<<LCD_ENTRY_MODE | 1<<LCD_ENTRY_INC);
   // set display to on
//   lcdControlWrite(1<<LCD_ON_CTRL | 1<<LCD_ON_DISPLAY | 1<<LCD_ON_BLINK);
   lcdControlWrite(1<<LCD_ON_CTRL | 1<<LCD_ON_DISPLAY );
   // move cursor to home
   lcdControlWrite(1<<LCD_HOME);
   // set data address to 0
   lcdControlWrite(1<<LCD_DDRAM | 0x00);


/*
   // load the first 8 custom characters
   lcdLoadCustomChar((u08*)LcdCustomChar,0,0);
   lcdLoadCustomChar((u08*)LcdCustomChar,1,1);
   lcdLoadCustomChar((u08*)LcdCustomChar,2,2);
   lcdLoadCustomChar((u08*)LcdCustomChar,3,3);
   lcdLoadCustomChar((u08*)LcdCustomChar,4,4);
   lcdLoadCustomChar((u08*)LcdCustomChar,5,5);
   lcdLoadCustomChar((u08*)LcdCustomChar,6,6);
   lcdLoadCustomChar((u08*)LcdCustomChar,7,7);
   */
}
/*
void lcd_home(void)
{
   // move cursor to home
   lcdControlWrite(1<<LCD_HOME);
}
  */
void lcd_clear(void)
{
   // clear LCD
   lcdControlWrite(1<<LCD_CLR);
}

void lcd_gotolc(unsigned char line, unsigned char col)
{
   register unsigned char DDRAMAddr;

   // remap lines into proper order
   switch(line)
   {
   case 0: DDRAMAddr = LCD_LINE0_DDRAMADDR+col; break;
   case 1: DDRAMAddr = LCD_LINE1_DDRAMADDR+col; break;
   case 2: DDRAMAddr = LCD_LINE2_DDRAMADDR+col; break;
   case 3: DDRAMAddr = LCD_LINE3_DDRAMADDR+col; break;
   default: DDRAMAddr = LCD_LINE0_DDRAMADDR+col;
   }

   // set data address
   lcdControlWrite(1<<LCD_DDRAM | DDRAMAddr);
}
/*
void lcdLoadCustomChar(u08* lcdCustomCharArray, u08 romCharNum, u08 lcdCharNum)
{
   register u08 i;
   u08 saveDDRAMAddr;

   // backup the current cursor position
   saveDDRAMAddr = lcdControlRead() & 0x7F;

   // multiply the character index by 8
   lcdCharNum = (lcdCharNum<<3);   // each character occupies 8 bytes
   romCharNum = (romCharNum<<3);   // each character occupies 8 bytes

   // copy the 8 bytes into CG (character generator) RAM
   for(i=0; i<8; i++)
   {
      // set CG RAM address
      lcdControlWrite((1<<LCD_CGRAM) | (lcdCharNum+i));
      // write character data
      // TODO:
//      lcdDataWrite( &lcdCustomCharArray+romCharNum+i );
   }

   // restore the previous cursor position
   lcdControlWrite(1<<LCD_DDRAM | saveDDRAMAddr);

}

// print with length
void lcdPrintData(char* sdata, unsigned char nBytes);

void lcdPrintData(char* sdata, unsigned char nBytes)
{
   register unsigned char i;

   // check to make sure we have a good pointer
   if (!sdata) return;

   // print data
   for(i=0; i<nBytes; i++)
   {
      lcdDataWrite(sdata[i]);
   }
}   */
void lcd_print(char* sdata)
{
//   lcdPrintData(sdata, strlen(sdata));
  int i;
   
  //limit 1 line display for prints
    for (i=0;sdata[i]!=0;i++)
   {
       lcdDataWrite(sdata[i]);         
    }
}


void lcd_print_at (char* text, unsigned char x,y)
{
  lcd_gotolc(y, x);
  while ( *text != 0 )
  {
    lcdDataWrite (*text++);
  }
}

void lcd_print_line (char* text, unsigned char line)
{
  unsigned char x;
  x=0;
     lcd_gotolc(line, 1);
    // lcdBusyWait(); //
  while (*text != 0)
  {
    lcdDataWrite (*text++);
   x++;
  }
 /* while (x++<16)
  {
    lcdDataWrite (" ");
	
  }*/	
}


/*void main()
{

	 lcd_init();
	 delaymslcd(100);
	 lcd_clear();
	 delaymslcd(100);
	 lcd_print_line("LCD TEST",0);
	 delaymslcd(100);	 
 	 lcd_print_line(" LCD works",1);
	delaymslcd(1000);
	 lcd_clear();
	 lcd_print_line("Tested OK",1);
	while(1);
} */