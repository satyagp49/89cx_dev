The Downloader software needs COM port between COM1 to COM6.
If your system has assigned CP2102 port to different number, then it will not work.
Refer to below page on how to change CP2102 chip COM port
http://www.sunrom.com/p/8051-development-board-sst89e51/install-usb-driver