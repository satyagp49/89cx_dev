#include <stdio.h> // for printf

#include "global.h"
#include "delay.h"			  

#include "glcd-128x64.h"		
#include "fontbig.h"	  

void print_big_char(unsigned int x, unsigned int y,unsigned char c);

char buf[20];
unsigned char counter;

char welcome_str[] = "Welcome";
void main()
{	
	GDispInit();

	while(1)
	{
		GDispClr(0x00);
			
		GDispPixStrAt(0,0, welcome_str, 1, BLACK);
		GDispPixStrAt(0,10,"Graphics LCD Demo", 1, BLACK);
		GDispPixStrAt(0,20,"Sunrom #(1121 & 1229)", 1, BLACK);		

		sprintf(buf,"Counter: %bu", counter++); // counter
		GDispPixStrAt(0,30, buf, 1, BLACK);

		// Print counter as 3 big digits
		print_big_char(0,38,  (counter / 100) ); //MSB
		print_big_char(24,38, ((counter/10)%10) );
		print_big_char(48,38, (counter%10) );	// LSB
		
		delay_ms(1000);
	}	
}

void print_big_char(unsigned int x, unsigned int y,unsigned char c)
{
	unsigned char v, l1, l2, l3, k;
	for(v=0;v<32;v++)
	{				
		l1=font32[((v*3)+0)+(c*96)];	
		l2=font32[((v*3)+1)+(c*96)];
		l3=font32[((v*3)+2)+(c*96)];

		for(k=0;k<8;k++)
		{
			if((l1)&(0x80>>k)) GDispSetPixel(x+k+0, y+v, BLACK);	
		}

		for(k=0;k<8;k++)
		{
			if((l2)&(0x80>>k)) GDispSetPixel(x+k+8, y+v, BLACK);	
		}

		for(k=0;k<8;k++)
		{
			if((l3)&(0x80>>k)) GDispSetPixel(x+k+16, y+v, BLACK);	
		}
	}
}





