//delay.h
#include "global.h"

void delay_ms(unsigned int x);