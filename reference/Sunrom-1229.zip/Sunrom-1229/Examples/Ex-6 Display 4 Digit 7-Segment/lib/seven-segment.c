//seven-segment.c
#include "seven-segment.h"
#include <intrins.h> // for _nop_

unsigned char display_buffer[4]; // we will seperate a integer and use this variable to store seperated digits
unsigned char segment_selected; // we will keep a track of which digit to switch on from 0 for digit1 and till 3 for digit 4

/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	This function breaks apart a given integer into separete digits
   and writes them to the display array i.e. digits[]   
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
void display_integer(unsigned int cnt)
{
   unsigned char i=0;
   unsigned char j;
   unsigned int num;
   num = cnt;
   while(num)
   {
      display_buffer[i]=num%10;
      i++;
      num=num/10;
   }
   for(j=i;j<4;j++) display_buffer[j]=10; // blank off leading zero
}

								
void display_shiftout(unsigned char c)
{
   unsigned char i;
   
   for (i=0; i<8; i++)
   {
      DAT = (c & 0x80) != 0;
	  c <<= 1;

	  CLK = 1;
	  _nop_();
	  CLK = 0;
   }
   
}
void display_off()
{
		  DIS1 = 1;
		  DIS2 = 1;
		  DIS3 = 1;
		  DIS4 = 1;
}
void display_select(unsigned char seg)
{
   switch(seg)
   {   
      case 0:
		  DIS1 = 0; // on
		  DIS2 = 1;
		  DIS3 = 1;
		  DIS4 = 1;        
      break;
      case 1:
		  DIS1 = 1;
		  DIS2 = 0; // on
		  DIS3 = 1;
		  DIS4 = 1;
      break;
      case 2:
		  DIS1 = 1;
		  DIS2 = 1;
		  DIS3 = 0; // on
		  DIS4 = 1;
      break;
      case 3:
		  DIS1 = 1;
		  DIS2 = 1;
		  DIS3 = 1;
		  DIS4 = 0; // on
      break;      
   }
}

void display_init()
{
	display_off();
	segment_selected = 0;
}

void display_refresh()
{
	display_off(); // Switch off segments for a while we send out digit

	display_shiftout( SegmentMapping[ display_buffer[ segment_selected ] ] );
    display_select(segment_selected);

	segment_selected++;		  // increment for next time cycle
	if(segment_selected == 4) // reset back to 0
		segment_selected = 0;
}