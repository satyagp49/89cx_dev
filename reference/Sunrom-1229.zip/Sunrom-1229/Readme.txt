The details in this package are for following product
Below page has more information
http://www.sunrom.com/p/8051-development-board-sst89e51