//adc.c
#include "adc.h"
// The MCP3008 is an 8 channel single-ended, or 4 channel differential ADC.

void init_adc()
{
	ADC_CS = 1; // disable
	ADC_CLK = 0;
	ADC_DI = 0;
}

unsigned int read_adc(unsigned char channel) // Channel = 0-7 
{
	unsigned char i,k;
	unsigned char command = 0;
	unsigned int AdcResult = 0;

	// ADC input = 1024*Vin/Vref
	command |= (1 << 7); // Start bit
	command |= (1 << 6); // Differential = 0; Single-ended input = 1;
	command |= ((channel & 7) << 3); // Set the channel(max 7)

	ADC_CS = 0; // Active chip select
	k++;// Delay about 1 uS
	ADC_CLK = 0;// make clock low first   
	k++;k++; 	
	
	/*--- write command 5 bit ----------*/
	for( i = 0; i < 5; i++ ) 
	{
		ADC_DI = (command & 0x80) != 0;
		command <<= 1;
		ADC_CLK = 1;
		k++; k++;                                                 // delay about 2 uS
		ADC_CLK = 0;
	} 
	
	/* --- read in one empty bit and one null bit and then 10 ADC bits -------- */
	k++; k++;                                                   // delay about 2 uS
	ADC_CLK = 1;
	k++; k++;                                                   // delay about 2 uS
	ADC_CLK = 0;
	k++; k++;                                                   // delay about 2 uS 

	k++; k++;                                                   // delay about 2 uS
	ADC_CLK = 1;
	k++; k++;                                                   // delay about 2 uS
	ADC_CLK = 0;
	k++; k++;                                                   // delay about 2 uS 

	/* --- read ADC result 10 bit -------- */
	AdcResult=0;
	
	for( i = 0; i < 10; i++ ) 
	{
		ADC_CLK = 1;
		k++; k++;                                    /// delay about 2 uS 
		AdcResult <<= 1;
		AdcResult = AdcResult | (ADC_DO & 0x01);         
		ADC_CLK = 0;
		k++; k++;                                    /// delay about 2 uS
	}
	ADC_CS=1;

	return AdcResult;
}