#include <REG51.H>

//LED Blink

sbit LED = P3^3;

void delay_ms(unsigned int x)	 // delays x msec (at fosc=11.0592MHz)
{
	unsigned char j=0;
	while(x-- > 0)
	{
		for (j=0; j<125; j++){;}
	}
}

void main()
{
	while(1)
	{
		LED = 0; // ON
		delay_ms(500);
		LED = 1; // OFF
		delay_ms(500);
	}	
}