
#include "keypad.h"

void delay_ms(unsigned int x)	 // delays x msec (at fosc=11.0592MHz)
{
	unsigned char j=0;
	while(x-- > 0)
	{
		for (j=0; j<125; j++){;}
	}
}

unsigned char read_key(void)
{
         ROW1 = 1;
         ROW2 = 1;
         ROW3 = 1;
         ROW4 = 1;
 
 //Scan COL1
         COL1 = 0;
         COL2 = 1;
         COL3 = 1;
         COL4 = 1;
 //SwX
         if(ROW1 == 0)
         {
                 delay_ms(50);
                 while(!ROW1);
				 delay_ms(10);
                 return 1;
         }
         if(ROW2 == 0)
         {
                 delay_ms(50);
                 while(!ROW2);
				 delay_ms(10);
                 return 2;
         }
         if(ROW3 == 0)
         {
                 delay_ms(50);
                 while(!ROW3);
				 delay_ms(10);
                 return 3;
         }
         if(ROW4 == 0)
         {
                 delay_ms(50);
                 while(!ROW4);
				 delay_ms(10);
                 return 4;
         }
 
 //Scan COL2
         COL1 = 1;
         COL2 = 0;
         COL3 = 1;
         COL4 = 1;
 //SwX
         if(ROW1 == 0)
         {
                 delay_ms(50);
                 while(!ROW1);
				 delay_ms(10);
                 return 5;
         }
         if(ROW2 == 0)
         {
                 delay_ms(50);
                 while(!ROW2);
				 delay_ms(10);
                 return 6;
         }
         if(ROW3 == 0)
         {
                 delay_ms(50);
                 while(!ROW3);
				 delay_ms(10);
                 return 7;
         }
         if(ROW4 == 0)
         {
                 delay_ms(50);
                 while(!ROW4);
				 delay_ms(10);
                 return 8;
         }

 //Scan COL3
         COL1 = 1;
         COL2 = 1;
         COL3 = 0;
         COL4 = 1;
 //SwX
         if(ROW1 == 0)
         {
                 delay_ms(50);
                 while(!ROW1);
				 delay_ms(10);
                 return 9;
         }
         if(ROW2 == 0)
         {
                 delay_ms(50);
                 while(!ROW2);
				 delay_ms(10);
                 return 10;
         }
         if(ROW3 == 0)
         {
                 delay_ms(50);
                 while(!ROW3);
				 delay_ms(10);
                 return 11;
         }
         if(ROW4 == 0)
         {
                 delay_ms(50);
                 while(!ROW4);
				 delay_ms(10);
                 return 12;
         }

 //Scan COL4
         COL1 = 1;
         COL2 = 1;
         COL3 = 1;
         COL4 = 0;
 //SwX
         if(ROW1 == 0)
         {
                 delay_ms(50);
                 while(!ROW1);
				 delay_ms(10);
                 return 13;
         }
         if(ROW2 == 0)
         {
                 delay_ms(50);
                 while(!ROW2);
				 delay_ms(10);
                 return 14;
         }
         if(ROW3 == 0)
         {
                 delay_ms(50);
                 while(!ROW3);
				 delay_ms(10);
                 return 15;
         }
         if(ROW4 == 0)
         {
                 delay_ms(50);
                 while(!ROW4);
				 delay_ms(10);
                 return 16;
         }
 return 0;
 }
