//serial.c
#include "serial.h"

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// -=-=-=-=- Setup Serial port for printf -=
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void init_serial(void)
{
  //9600 bps @ 11.059 MHz
  SCON = 0x50; /* Setup serial port control register */
  /* Mode 1: 8-bit uart var. baud rate */
  /* REN: enable receiver */
  PCON &= 0x7F; /* Clear SMOD bit in power ctrl reg */
  /* This bit doubles the baud rate */
  TMOD &= 0xCF; /* Setup timer/counter mode register */
  /* Clear M1 and M0 for timer 1 */
  TMOD |= 0x20; /* Set M1 for 8-bit autoreload timer */
  TH1 = 0xFD; /* Set autoreload value for timer 1 */
  /* 9600 baud with 11.0592 MHz xtal */
  TR1 = 1; /* Start timer 1 */
  TI = 1; /* Set TI to indicate ready to xmit */
}