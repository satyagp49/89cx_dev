//adc.h
#include "global.h"

// Connections ADC
sbit ADC_CS		= P3^4;
sbit ADC_CLK	= P3^5;
sbit ADC_DO		= P3^6;
sbit ADC_DI		= P3^7;

void init_adc();
unsigned int read_adc(unsigned char channel); // Channel = 0-7 