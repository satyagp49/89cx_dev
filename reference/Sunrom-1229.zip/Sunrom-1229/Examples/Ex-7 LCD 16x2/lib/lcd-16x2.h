//lcd-16x2.h
#include "global.h"

#ifndef _LCD16x2_H_
#define _LCD16x2_H_

//**   Standard 8051 Port definition   **//
#define P0   0x80
#define P1   0x90
#define P2   0xA0
#define P3   0xB0

//**   Which Port is LCD connected   **//
#define LCD_PORT P2

void lcd_init (void);
void lcd_clear(void);
void lcd_print_at (char* text, unsigned char x,y);
void lcd_print_line (char* text,unsigned char y);

#endif
