//seven-segment.h
#include "global.h"

#ifndef __SEVENSEGMENT_H__
#define __SEVENSEGMENT_H__

sbit DIS1 = P2^2;
sbit DIS2 = P2^1;
sbit DIS3 = P2^0;
sbit DIS4 = P2^3;

sbit DAT = P2^4;
sbit CLK = P2^5;

// This array has values as to which segment becomes on for a digit from 0 to 9
static unsigned char code SegmentMapping[11] =
{
	192, //0
	249, //1
	164, //2
	176, //3
	153, //4
	146, //5
	130, //6
	248, //7
	128, //8
	144, //9
	0xFF //OFF=10
};

void display_init();
void display_refresh();
void display_integer(unsigned int cnt); // separate a integer into 4 bytes to display buffer
#endif