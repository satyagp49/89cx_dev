#include <stdio.h> // for printf

#include "global.h"
#include "delay.h"
#include "adc.h"		 
#include "serial.h"					  

sbit LED = P3^3;
sbit SW  = P3^2;

void main()
{
	unsigned int ADC0, ADC0_mV, temperature;
	init_serial();
	init_adc();

	while(1)
	{
		ADC0 = read_adc( 0 ); // read channel 0 = on board temperature sensor MCP9700

		// Convert ADC reading to milivolts 
		// ADC Ref voltage 4096mV(4.096V) MCP1541
		// ADC 10 bit = 1024
		// one ADC unit will be 4096/1024 = 4mV
		// eg Z ADC reading to mV will be Z x 4mV 
		ADC0_mV = ADC0 * 4; 

		// convert mV to temperature in celcius
		// MCP9700 on board temperature sensor 
		// outputs 500mV offset plus 10mv per Deg Celcius
		temperature = 0; // clear value
		if(ADC0_mV > 500) // valid value is always at 500mV offset
		{
			temperature = ADC0_mV - 500; // remove the offset
			temperature = temperature / 10; // mv to Celcius 10mV/C
		}
		printf( "Temperature:%4d%cC (ADC0:%4d =%4dmV)\r", temperature, 176, ADC0, ADC0_mV ); // 176 is degree chracter
		delay_ms(500); // delay to send reading every 500ms

		LED = SW; // For testing, Put LED on when switch is pressed
	}	
}





