#include <stdio.h> // for printf

#include "global.h"
#include "delay.h"			  
#include "lcd-16x2.h"		

unsigned int 	counter;
char 			str_buf[20];	
char    		welcome[]   =   "....Welcome....";	  

void main()
{	
	lcd_init();

  	lcd_print_line (welcome, 0); 		// line1
  	lcd_print_line ("LCD Demo", 1); 	// line2
	delay_ms(1000);

	while(1)
	{
		lcd_clear();
		lcd_print_line ("Sunrom 16x2 LCD", 0); 		// line1
		sprintf (str_buf, "Count: %d", counter++);	// line2
		lcd_print_line (str_buf, 1);				
		delay_ms(500);
	}	
}





