//serial.h
#include "global.h"

void init_serial(void);