//**   Standard 8051 Port definition   **//
#define P0   0x80
#define P1   0x90
#define P2   0xA0
#define P3   0xB0

sfr KEYBOARD_DATA = P2;

sbit	COL1		=	KEYBOARD_DATA^0;
sbit	COL2		=	KEYBOARD_DATA^1;
sbit	COL3		=	KEYBOARD_DATA^2;
sbit	COL4		=	KEYBOARD_DATA^3;

sbit	ROW1		=	KEYBOARD_DATA^4;
sbit	ROW2		=	KEYBOARD_DATA^5;
sbit	ROW3		=	KEYBOARD_DATA^6;
sbit	ROW4		=	KEYBOARD_DATA^7;

unsigned char read_key(void);